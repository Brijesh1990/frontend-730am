// alert('Hello guys i am just load amazon click on OK')
// window.location='https://www.amazon.com';
// var a='Hello world i am javascript';
// document.write(a);

// alert('Hello guys i am just load amazon click on OK')
// window.location='https://www.amazon.com';  //BOM (broswer object module)

console.log("Hello guys i am just load amazon click on OK");

